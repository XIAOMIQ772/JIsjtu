# 交我集'使用说明

## 安装

下载压缩包之后，运行install.sh

## 配置功能文件

终端运行
cd ~/.local/share/JIsjtu/.env && vim .env
按下 i 进入编辑模式

### 可选配置

#### agent核心

当前仅支持openai协议
建议使用deepseek，因为响应速率无与伦比
格式为
OPENAI_BASE_URL=""
OPENAI_API_KEY=""

#### canvas相关功能
canvas功能包括查看课程，查看课程发布的作业信息以及下载课件
该配置文件获取途径如下：
进入canvas，点击左上角账户->设置
下拉创建访问许可证


CANVAS_API_TOKEN=""

#### 邮箱相关功能 
包括查询未读邮件，查看邮件详细信息

以下分别是jaccount的账号和密码
EMAIL_USER_ACCOUNT=""
EMAIL_USER_PASSWORD=""

以下为默认配置，输入即可
IMAP_HOST="imap.sjtu.edu.cn"
IMAP_PORT="993"

### 配置完毕后
按下esc ，输入 :wq ,按下回车，文件保存完毕

## 启动方式

在终端任意目录下输入JIsjtu即可启动交我集